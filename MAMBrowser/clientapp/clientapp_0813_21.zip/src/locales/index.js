
import ko from './ko.json'

const messages = { ko: ko };

export default messages;