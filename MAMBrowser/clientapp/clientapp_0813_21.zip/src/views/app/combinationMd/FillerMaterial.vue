<template>
  <div>
    <template-filler-form heading="필러(기본)" type="general"></template-filler-form>
  </div>
</template>

<script>
import TemplateFillerForm from './template/templateFillterForm';

export default {
  components: { TemplateFillerForm },
}
</script>