<template>
  <div>
    <template-filler-form heading="필러(pr)" type="pr"></template-filler-form>
  </div>
</template>

<script>
import TemplateFillerForm from './template/templateFillterForm';

export default {
  components: { TemplateFillerForm },
}
</script>