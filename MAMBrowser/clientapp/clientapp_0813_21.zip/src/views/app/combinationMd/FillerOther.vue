<template>
  <div>
    <template-filler-form heading="필터(기타)" type="etc"></template-filler-form>
  </div>
</template>

<script>
import TemplateFillerForm from './template/templateFillterForm';

export default {
  components: { TemplateFillerForm },
}
</script>