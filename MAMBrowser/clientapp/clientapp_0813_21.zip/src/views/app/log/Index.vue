<template>
  <div>
    <b-row>
      <b-colxx xxs="12">
        <piaf-breadcrumb heading="사용자 로그보기"/>
        <div class="separator mb-3"></div>
      </b-colxx>
    </b-row>
    <b-row>
        <b-colxx>
            <b-card>
                <!-- 검색 -->
                <b-container fluid>
                <div class="search-form-area">
                    <b-form @submit.stop>
                    <b-row>
                        <!-- 로그 레벨 -->
                        <b-colxx sm="2">
                        <b-form-group label="제목" class="has-float-label c-zindex">
                            <c-input-text v-model="searchItems.title" />
                        </b-form-group>
                        </b-colxx>
                        <!-- 작업자 -->
                        <b-colxx sm="2">
                        <b-form-group label="메모" class="has-float-label c-zindex">
                            <c-input-text v-model="searchItems.memo" />
                        </b-form-group>
                        </b-colxx>
                        <!-- 기간: 시작일 -->
                        <b-colxx sm="2">
                        <b-form-group label="시작일" class="has-float-label c-zindex">
                            <c-input-date-picker v-model="searchItems.start_dt" />
                            <!-- <b-form-invalid-feedback
                            :state="$v.searchItems.start_dt.check_date"
                            >날짜 형식이 맞지 않습니다.</b-form-invalid-feedback> -->
                        </b-form-group>
                        </b-colxx>
                        <!-- 기간: 종료일 -->
                        <b-colxx sm="2">
                        <b-form-group label="종료일" class="has-float-label c-zindex">
                            <c-input-date-picker v-model="searchItems.end_dt" />
                            <!-- <b-form-invalid-feedback
                            :state="$v.searchItems.end_dt.check_date"
                            >날짜 형식이 맞지 않습니다.</b-form-invalid-feedback> -->
                        </b-form-group>
                        </b-colxx>
                        <b-colxx sm="2">
                        <b-button class="mb-1" variant="primary default" @click="getData">검색</b-button>
                        </b-colxx>
                    </b-row>
                    </b-form>
                </div>
                <!-- 테이블 -->

                </b-container>
            </b-card>
        </b-colxx>
    </b-row>
  </div>
</template>
<script>
import MixinLogPage from '../../../mixin/MixinLogPage';

export default {
    mixins: [ MixinLogPage ],
    data() {
        return {
            searchItems: {
                title: '',             // 제목
                memo: '',              // 메모(memo)
                start_dt: '20200101',  // 등록일 시작일
                end_dt: '20200730',    // 등록일 종료일
                rowPerPage: 16,
                selectPage: 1,
                sortKey: '',
                sortValue: '',
            },
        }
    },
    methods: {
        getData() {

        },
    }
}
</script>
