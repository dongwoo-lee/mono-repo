<template>
  <div>
    <templateSBForm heading="CM"></templateSBForm>
  </div>
</template>

<script>
import templateSBForm from './template/templateSBForm';

export default {
  components: { templateSBForm },
}
</script>