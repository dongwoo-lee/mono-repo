<template>
  <div>
    <templateSBForm heading="주조SB" type="mcr"></templateSBForm>
  </div>
</template>

<script>
import templateSBForm from './template/templateSBForm';

export default {
  components: { templateSBForm },
}
</script>