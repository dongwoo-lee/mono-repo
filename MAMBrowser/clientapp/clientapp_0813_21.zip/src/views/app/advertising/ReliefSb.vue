<template>
  <div>
    <templateSBForm heading="부조SB" type="scr"></templateSBForm>
  </div>
</template>

<script>
import templateSBForm from './template/templateSBForm';

export default {
  components: { templateSBForm },
}
</script>